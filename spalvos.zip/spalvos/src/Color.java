enum Color {
    RED, GREEN, BLUE;

    char getCode() {
        return this.name().charAt(0);
    }

}

class ColorChar {
    public static void main(String[] args) {
        for (Color color : Color.values())
            System.out.println(color.name() + " - " +color.getCode());
    }
}