public interface Three {
    static void printStatic () {
        System.out.println("static");
    }
}
