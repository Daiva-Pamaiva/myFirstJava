public abstract class Two {
    void printNothing() {
        System.out.println();
    }
}
