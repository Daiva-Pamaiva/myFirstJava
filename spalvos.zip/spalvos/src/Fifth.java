public class Fifth {
   public int viesas;
   protected int apsaugotas;
}
