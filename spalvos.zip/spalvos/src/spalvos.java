public class spalvos {

        public static void main(String[] args) {
            int kiek = 0;
            int suma = 0;
                for (int i = 100;; i--, kiek++)
                {
                    if(kiek == 3)
                        break;
                    suma += i;
                }
                System.out.println(suma);
            }
    }

