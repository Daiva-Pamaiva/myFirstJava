public class ThreeMain {
    public static void main(String[] args) {
        Three.printStatic();
    }
}
