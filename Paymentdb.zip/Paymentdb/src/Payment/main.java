package Payment;

public class main {
    public static void main(String[] args) {
        System.out.println("Saskaitos numeris:" + bankAccount);
        System.out.println("Saskaitos savininkas:" + accountOwner);
        System.out.println("Pervedama suma:" + amount);
    }
}
