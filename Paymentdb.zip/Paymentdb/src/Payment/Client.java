package Payment;

public class Client implements Payment {
    private String vardas;
    private double amount;
    private String bankAccount;


    public Client (String vardas, double amount, String bankAccount) {
        this.vardas = vardas;
        this.amount = amount;
        this.bankAccount = bankAccount;
    }

    @Override
    public int bankAccount() {
        return 0;
    }

    @Override
    public String accountOwner() {
        return null;
    }

    @Override
    public double amount() {
        return 0;
    }

    public String getVardas() {
        return vardas;
    }

    public double getAmount() {
        return amount;
    }

    public String getBankAccount() {
        return bankAccount;
    }
}
