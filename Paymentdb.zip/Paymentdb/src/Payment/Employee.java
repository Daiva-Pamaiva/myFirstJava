package Payment;

public class Employee implements Payment {
    private String vardas;
    private double amount;
    private String bankAccount;

    public Employee (String vardas, double amount, String bankAccount) {
        this.vardas = vardas;
        this.amount = amount;
        this.bankAccount = bankAccount;
    }

    @Override
    public int bankAccount() {
        return 0;
    }

    @Override
    public String accountOwner() {
        return vardas;
    }

    @Override
    public double amount() {
        return amount;
    }

    public String getVardas() {
        return vardas;
    }

    public double getAmount() {
        return amount;
    }

    public String getBankAccount() {
        return bankAccount;
    }
}
