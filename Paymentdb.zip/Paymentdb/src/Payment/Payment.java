package Payment;

public interface Payment {
    int bankAccount();
    String accountOwner ();
    double amount ();
}
